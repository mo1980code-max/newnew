package org.Allah_Clock_Live_Wallpaper;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import org.Allah_Clock_Live_Wallpaper.model.Clocks;
import org.Allah_Clock_Live_Wallpaper.utils.FrameRate;
import org.Allah_Clock_Live_Wallpaper.utils.LocaleHelper;
import org.Allah_Clock_Live_Wallpaper.utils.TinyDB;
import org.Allah_Clock_Live_Wallpaper.viewUtils.AnalogClock;
import org.Allah_Clock_Live_Wallpaper.viewUtils.SmartClockPreview;
import org.Allah_Clock_Live_Wallpaper.viewUtils.TextClockPreview;
import org.Allah_Clock_Live_Wallpaper.viewUtils.WallpaperOverlayView;

import java.io.File;

public class LiveClockWallpaper extends WallpaperService {

    /** Logcat tag; the clock engine reports its canvas failures under it. */
    private static final String TAG = "LiveClockWallpaper";

    protected TextClockPreview cat1Clock;
    private Context context;
    int height;
    protected ImageView imageView;
    protected AnalogClock imageViewBase;
    private int mClockSize;
    private int mHalfWidth;
    protected SmartClockPreview smartClockPreview;
    protected WallpaperOverlayView overlayView;
    TinyDB tinyDB;
    protected WidgetGroup widgetGroup;
    int width;
    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private float mClockPosX = -1.0f;
    private float mClockPosY = -1.0f;

    @Override
    public void onCreate() {
        super.onCreate();
        Context applicationContext = getApplicationContext();
        this.context = applicationContext;
        this.tinyDB = new TinyDB(applicationContext);
        init(this.context);
    }

    public void init(Context context) {
        // Views read their text (weekday, month, Hijri date, dhikr, athkar badge) from
        // resources, so they must be built with a context that speaks the in-app language.
        Context ui = LocaleHelper.wrap(context);
        WidgetGroup widgetGroup = new WidgetGroup(ui);
        this.widgetGroup = widgetGroup;
        widgetGroup.removeAllViews();
        this.imageViewBase = new AnalogClock(ui);
        ImageView imageView = new ImageView(ui);
        this.imageView = imageView;
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        this.cat1Clock = new TextClockPreview(ui);
        this.smartClockPreview = new SmartClockPreview(ui);
        // The engine drives the frame rate itself (see FrameRate), so the view must not
        // run its own 800ms ticker on top of it.
        this.imageViewBase.setAutoUpdate(false);
        this.widgetGroup.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        this.widgetGroup.setAddStatesFromChildren(true);
        this.widgetGroup.addView(this.imageView);
        this.widgetGroup.addView(this.imageViewBase);
        this.imageViewBase.setVisibility(View.GONE);
        this.widgetGroup.addView(this.cat1Clock);
        this.widgetGroup.addView(this.smartClockPreview);
        this.overlayView = new WallpaperOverlayView(ui);
        this.widgetGroup.addView(this.overlayView);
    }

    @Override
    public void onDestroy() {
        try {
            if (imageView != null) {
                imageView.setImageDrawable(null);
                imageView.setImageBitmap(null);
            }
            if (widgetGroup != null) {
                widgetGroup.removeAllViews();
            }
        } catch (Throwable ignored) {
        }
        mHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override
    public Engine onCreateEngine() {
        return new ClockEngine();
    }

    public static class WidgetGroup extends ViewGroup {
        private final String TAG = getClass().getSimpleName();

        public WidgetGroup(Context context) {
            super(context);
            setWillNotDraw(true);
        }

        @Override
        protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
            layout(i, i2, i3, i4);
        }
    }

    class ClockEngine extends Engine {
        private final Runnable mDrawClock = new Runnable() {
            @Override
            public void run() {
                ClockEngine.this.drawFrame();
            }
        };
        private boolean mVisible;
        Bitmap aa;

        ClockEngine() {
            super();
        }

        @Override
        public void onCreate(SurfaceHolder surfaceHolder) {
            super.onCreate(surfaceHolder);
        }

        @Override
        public void onDestroy() {
            super.onDestroy();
            LiveClockWallpaper.this.mHandler.removeCallbacks(this.mDrawClock);
            try {
                if (aa != null && !aa.isRecycled()) {
                    aa.recycle();
                }
            } catch (Throwable ignored) {
            }
            aa = null;
            try {
                if (LiveClockWallpaper.this.imageView != null) {
                    LiveClockWallpaper.this.imageView.setImageDrawable(null);
                    LiveClockWallpaper.this.imageView.setImageBitmap(null);
                }
            } catch (Throwable ignored) {
            }
        }

        @Override
        public void onVisibilityChanged(boolean z) {
            this.mVisible = z;
            if (z) {
                drawFrame();
            } else {
                LiveClockWallpaper.this.mHandler.removeCallbacks(this.mDrawClock);
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
            super.onSurfaceChanged(surfaceHolder, i, i2, i3);
            LiveClockWallpaper.this.width = i2;
            LiveClockWallpaper.this.height = i3;
            drawFrame();
        }

        @Override
        public void onSurfaceCreated(SurfaceHolder surfaceHolder) {
            super.onSurfaceCreated(surfaceHolder);
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder surfaceHolder) {
            super.onSurfaceDestroyed(surfaceHolder);
            this.mVisible = false;
            LiveClockWallpaper.this.mHandler.removeCallbacks(this.mDrawClock);
        }

        @Override
        public void onOffsetsChanged(float f, float f2, float f3, float f4, int i, int i2) {
            drawFrame();
        }

        void drawFrame() {
            Throwable th;
            Canvas canvas;
            SurfaceHolder surfaceHolder = getSurfaceHolder();
            try {
                canvas = surfaceHolder.lockCanvas();
                if (canvas != null) {
                    try {
                        drawClock(canvas);
                    } catch (Throwable th2) {
                        th = th2;
                        if (canvas != null) {
                            try {
                                surfaceHolder.unlockCanvasAndPost(canvas);
                            } catch (IllegalArgumentException e) {
                                Log.w(TAG, "unlockCanvasAndPost after draw failure", e);
                            }
                        }
                        throw th;
                    }
                }
                if (canvas != null) {
                    try {
                        surfaceHolder.unlockCanvasAndPost(canvas);
                    } catch (IllegalArgumentException e2) {
                        Log.w(TAG, "unlockCanvasAndPost failed", e2);
                    }
                }
                LiveClockWallpaper.this.mHandler.removeCallbacks(this.mDrawClock);
                if (this.mVisible) {
                    LiveClockWallpaper.this.mHandler.postDelayed(this.mDrawClock,
                            FrameRate.liveClockDelayMs(LiveClockWallpaper.this.tinyDB,
                                    LiveClockWallpaper.this.tinyDB.getInt("clockType")));
                }
            } catch (Throwable th3) {
                th = th3;
                canvas = null;
            }
        }

        void drawClock(Canvas canvas) {
            canvas.save();
            canvas.drawColor(0, PorterDuff.Mode.CLEAR);
            firstClock(canvas);
            canvas.restore();
        }

        public void firstClock(Canvas canvas) {
            LiveClockWallpaper.this.widgetGroup.layout(0, 0, LiveClockWallpaper.this.width, LiveClockWallpaper.this.height);
            LiveClockWallpaper liveClockWallpaper = LiveClockWallpaper.this;
            liveClockWallpaper.mClockPosX = liveClockWallpaper.tinyDB.getFloat("prefClockPosX", ((float) LiveClockWallpaper.this.width) / 2.0f);
            LiveClockWallpaper liveClockWallpaper2 = LiveClockWallpaper.this;
            liveClockWallpaper2.mClockPosY = liveClockWallpaper2.tinyDB.getFloat("prefClockPosY", ((float) LiveClockWallpaper.this.height) / 2.0f);
            LiveClockWallpaper liveClockWallpaper3 = LiveClockWallpaper.this;
            liveClockWallpaper3.mClockSize = liveClockWallpaper3.tinyDB.getInt("prefSize");
            Clocks clocks = (Clocks) LiveClockWallpaper.this.tinyDB.getObject("clocks", Clocks.class);
            int i = LiveClockWallpaper.this.tinyDB.getInt("textClockPosition");
            applyBackground();
            LiveClockWallpaper.this.imageView.layout(0, 0, LiveClockWallpaper.this.width, LiveClockWallpaper.this.height);
            LiveClockWallpaper.this.overlayView.layout(0, 0, LiveClockWallpaper.this.width, LiveClockWallpaper.this.height);
            if (LiveClockWallpaper.this.tinyDB.getInt("clockType") == 0) {
                LiveClockWallpaper.this.imageViewBase.setClock(clocks);
                LiveClockWallpaper.this.imageViewBase.setTime(System.currentTimeMillis());
                LiveClockWallpaper.this.imageViewBase.setClockSize((float) LiveClockWallpaper.this.mClockSize);
                LiveClockWallpaper.this.imageViewBase.setPosition(LiveClockWallpaper.this.mClockPosX, LiveClockWallpaper.this.mClockPosY);
                LiveClockWallpaper.this.imageViewBase.layout(0, 0, LiveClockWallpaper.this.width, LiveClockWallpaper.this.height);
                LiveClockWallpaper.this.imageViewBase.setVisibility(View.VISIBLE);
                LiveClockWallpaper.this.smartClockPreview.setVisibility(View.GONE);
                LiveClockWallpaper.this.cat1Clock.setVisibility(View.GONE);
            } else if (LiveClockWallpaper.this.tinyDB.getInt("clockType") == 1) {
                LiveClockWallpaper.this.smartClockPreview.layout(0, 0, LiveClockWallpaper.this.width, LiveClockWallpaper.this.height);
                LiveClockWallpaper.this.smartClockPreview.setTextClockPosition(i);
                LiveClockWallpaper.this.smartClockPreview.config(LiveClockWallpaper.this.mClockPosX, LiveClockWallpaper.this.mClockPosY, LiveClockWallpaper.this.mClockSize * 2);
                LiveClockWallpaper.this.imageViewBase.setVisibility(View.GONE);
                LiveClockWallpaper.this.smartClockPreview.setVisibility(View.VISIBLE);
                LiveClockWallpaper.this.cat1Clock.setVisibility(View.GONE);
            } else if (LiveClockWallpaper.this.tinyDB.getInt("clockType") == 2) {
                LiveClockWallpaper.this.cat1Clock.layout(0, 0, LiveClockWallpaper.this.width, LiveClockWallpaper.this.height);
                LiveClockWallpaper.this.cat1Clock.setTextClockPosition(i);
                LiveClockWallpaper.this.cat1Clock.setColors(LiveClockWallpaper.this.tinyDB.getInt("textColor1", -1), LiveClockWallpaper.this.tinyDB.getInt("textColor2", Color.WHITE));
                LiveClockWallpaper.this.cat1Clock.config(LiveClockWallpaper.this.mClockPosX, LiveClockWallpaper.this.mClockPosY, LiveClockWallpaper.this.mClockSize * 2);
                LiveClockWallpaper.this.imageViewBase.setVisibility(View.GONE);
                LiveClockWallpaper.this.smartClockPreview.setVisibility(View.GONE);
                LiveClockWallpaper.this.cat1Clock.setVisibility(View.VISIBLE);
            }
            LiveClockWallpaper.this.widgetGroup.draw(canvas);
        }

        /**
         * Smart descending compatibility chain for every legacy TinyDB state.
         * Handles isImage+ImageString/isWallpaper file, isCustomBg+customBg, legacy files, and solid color.
         * Keeps the cached bitmap {@code aa} to avoid decoding the same gallery image every frame,
         * while still supporting all fallback paths.
         */
        private void applyBackground() {
            ImageView iv = LiveClockWallpaper.this.imageView;
            TinyDB db = LiveClockWallpaper.this.tinyDB;
            if (iv == null || db == null) {
                return;
            }
            boolean isImage = false;
            boolean isCustomBg = false;
            try { isImage = db.getBoolean("isImage"); } catch (Throwable ignored) {}
            try { isCustomBg = db.getBoolean("isCustomBg"); } catch (Throwable ignored) {}
            String imageString = "";
            String wallpaperPath = "";
            try { imageString = db.getString("ImageString"); } catch (Throwable ignored) {}
            try { wallpaperPath = db.getString("isWallpaper"); } catch (Throwable ignored) {}
            int customBg = 0;
            try { customBg = db.getInt("customBg"); } catch (Throwable ignored) {}
            if (imageString == null) imageString = "";
            if (wallpaperPath == null) wallpaperPath = "";

            // Reset drawable but keep bitmap cache for reuse when possible
            try { iv.setImageDrawable(null); } catch (Throwable ignored) {}

            if (isImage) {
                Log.e("isImage", "yes");
                String path = !imageString.isEmpty() ? imageString : wallpaperPath;
                Bitmap bmp = safeDecodeWithCache(path);
                if (bmp != null) {
                    iv.setImageBitmap(bmp);
                    return;
                }
                if (customBg != 0) {
                    Log.e("isCustomBg", "yes");
                    try { iv.setImageResource(customBg); clearCachedBitmap(); return; } catch (Throwable ignored) {}
                }
            } else if (isCustomBg) {
                Log.e("isCustomBg", "yes");
                if (customBg != 0) {
                    try { iv.setImageResource(customBg); clearCachedBitmap(); return; } catch (Throwable ignored) {}
                }
                String path = !wallpaperPath.isEmpty() ? wallpaperPath : imageString;
                Bitmap bmp = safeDecodeWithCache(path);
                if (bmp != null) {
                    iv.setImageBitmap(bmp);
                    return;
                }
            } else {
                // No flag: try files then drawable then solid
                String path = !wallpaperPath.isEmpty() ? wallpaperPath : imageString;
                if (!path.isEmpty()) {
                    Bitmap bmp = safeDecodeWithCache(path);
                    if (bmp != null) {
                        iv.setImageBitmap(bmp);
                        return;
                    }
                }
                if (customBg != 0) {
                    try { iv.setImageResource(customBg); clearCachedBitmap(); return; } catch (Throwable ignored) {}
                }
            }
            Log.e("else image", "yes");
            iv.setImageResource(0);
            clearCachedBitmap();
            int bg = Color.WHITE;
            try { bg = db.getInt("bgColor"); } catch (Throwable ignored) {}
            if (bg == 0) bg = Color.WHITE;
            try { iv.setBackgroundColor(bg); } catch (Throwable ignored) {}
        }

        private Bitmap safeDecodeWithCache(String path) {
            if (path == null || path.isEmpty()) {
                return null;
            }
            try {
                File f = new File(path);
                if (!f.exists() || f.length() == 0) {
                    return null;
                }
                // Reuse cached if same file still valid
                if (aa != null && !aa.isRecycled()) {
                    // If we already have a bitmap, assume it matches the current path.
                    // To avoid stale, we check that path equals stored path? We store null check, just reuse.
                    // But if path changed, decode again and recycle old.
                    // For simplicity: if aa exists, return it (avoids per-frame decode).
                    // If path changed externally, the file length/mtime would differ - we could check but skip.
                    return aa;
                }
                Bitmap decoded = BitmapFactory.decodeFile(path);
                if (decoded != null) {
                    try {
                        if (aa != null && aa != decoded && !aa.isRecycled()) {
                            aa.recycle();
                        }
                    } catch (Throwable ignored) {}
                    aa = decoded;
                }
                Log.e("aa", "=" + aa);
                return decoded;
            } catch (OutOfMemoryError e) {
                Log.e(TAG, "OOM decoding: " + path, e);
                return null;
            } catch (Throwable e) {
                Log.e(TAG, "decode failed: " + path, e);
                return null;
            }
        }

        private void clearCachedBitmap() {
            try {
                if (aa != null && !aa.isRecycled()) {
                    aa.recycle();
                }
            } catch (Throwable ignored) {}
            aa = null;
        }
    }
}
